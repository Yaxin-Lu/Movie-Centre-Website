package com.example.myapplication.ui.home;

public class CardItem {
    public String name;
    public String type;
    public String id;
    public String img_url;

    public CardItem(String s1, String s2, String s3, String s4){
        name = s1;
        type = s2;
        id = s3;
        img_url = s4;
    }
}
