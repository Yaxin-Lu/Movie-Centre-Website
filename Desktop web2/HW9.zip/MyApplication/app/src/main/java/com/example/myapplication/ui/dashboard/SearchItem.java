package com.example.myapplication.ui.dashboard;

public class SearchItem {
     String url_img;
     String name;
     String id;
     String type;
     String time;
     String vote;
     public SearchItem(String s1, String s2, String s3,String s4, String s5, String s6){
          url_img = s1;
          name = s2;
          id = s3;
          type = s4;
          time = s5;
          vote = s6;
     }


}
